package com.spring.tacoscloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TacosCloudApplicationTests {

	@Test
	void contextLoads() {
	}

}
