package com.example.springgumball;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringGumballApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringGumballApplication.class, args);
	}

}
