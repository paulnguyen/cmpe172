package com.example.springldap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLdapApplicationTests {

	@Test
	void contextLoads() {
	}

}
