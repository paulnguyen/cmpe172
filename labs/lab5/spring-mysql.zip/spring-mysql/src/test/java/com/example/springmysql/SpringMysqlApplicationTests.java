package com.example.springmysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
